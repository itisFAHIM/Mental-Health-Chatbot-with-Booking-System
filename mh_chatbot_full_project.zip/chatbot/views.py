import os, json, requests
from django.shortcuts import render
from django.http import JsonResponse
from django.contrib.auth import authenticate
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from .serializers import RegisterSerializer, UserSerializer, MessageSerializer
from .models import Message
from dotenv import load_dotenv
load_dotenv()
HF_API_TOKEN = os.getenv('HF_API_TOKEN')
HF_MODEL = 'facebook/blenderbot-400M-distill'
HF_API_URL = f'https://api-inference.huggingface.co/models/{HF_MODEL}'

def index(request):
    return render(request, 'chatbot/index.html', {})
def login_page(request):
    return render(request, 'chatbot/login.html', {})
def signup_page(request):
    return render(request, 'chatbot/signup.html', {})

@api_view(['POST'])
@permission_classes([AllowAny])
def register_view(request):
    serializer = RegisterSerializer(data=request.data)
    if serializer.is_valid():
        user = serializer.save()
        token, _ = Token.objects.get_or_create(user=user)
        return JsonResponse({'token': token.key, 'user': UserSerializer(user).data})
    return JsonResponse({'errors': serializer.errors}, status=400)

@api_view(['POST'])
@permission_classes([AllowAny])
def login_view(request):
    username = request.data.get('username') or ''
    password = request.data.get('password') or ''
    user = authenticate(username=username, password=password)
    if user is None:
        return JsonResponse({'error':'invalid_credentials'}, status=400)
    token, _ = Token.objects.get_or_create(user=user)
    return JsonResponse({'token': token.key, 'user': UserSerializer(user).data})

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def chat_api(request):
    user = request.user
    message = request.data.get('message','').strip()
    if not message:
        return JsonResponse({'error':'empty_message'}, status=400)
    Message.objects.create(user=user, sender=Message.SENDER_USER, text=message)
    if not HF_API_TOKEN:
        reply = "I can't access my knowledge right now. Please seek professional help if urgent."
        Message.objects.create(user=user, sender=Message.SENDER_BOT, text=reply)
        return JsonResponse({'reply': reply})
    headers = {'Authorization': f'Bearer {HF_API_TOKEN}', 'Accept': 'application/json'}
    payload = {'inputs': message}
    try:
        resp = requests.post(HF_API_URL, headers=headers, json=payload, timeout=30)
        resp.raise_for_status()
        result = resp.json()
        reply = ''
        if isinstance(result, dict) and 'generated_text' in result:
            reply = result['generated_text']
        elif isinstance(result, list) and len(result)>0 and isinstance(result[0], dict):
            reply = result[0].get('generated_text') or result[0].get('summary_text') or str(result[0])
        else:
            reply = str(result)
        if not reply:
            reply = "I'm sorry — I couldn't generate a response."
        Message.objects.create(user=user, sender=Message.SENDER_BOT, text=reply)
        return JsonResponse({'reply': reply})
    except requests.exceptions.RequestException:
        reply = "Sorry, I can't reach the model service right now."
        Message.objects.create(user=user, sender=Message.SENDER_BOT, text=reply)
        return JsonResponse({'reply': reply}, status=503)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def history_api(request):
    user = request.user
    qs = Message.objects.filter(user=user).order_by('-created_at')[:500]
    serializer = MessageSerializer(qs, many=True)
    return JsonResponse({'messages': serializer.data})
